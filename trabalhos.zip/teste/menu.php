<div>
    <ul>
        <li>
            <a href ng-click="tab.selected(1)">Lista de Compras</a>
        </li>
    <ul>

    <terceira ng-show="tab.isSelected(1)"></terceira>
</div>

