
    <h1> Ola</h1>
    <label class="label-control"> LISTA DE COMPRAS </label>
    <input type="radio" name="listar" value="Frutas"> Frutas
    <input type="radio" name="listar" value="Verduras"> Verduras
    <input type="radio" name="listar" value="Carne"> Carnes
    <input type="radio" name="listar" value="Sessão"> Sessão
