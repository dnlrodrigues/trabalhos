function myController($scope){
    $scope.objeto = {};
    $scope.objetos = [];
    $scope.colunas = ['Qtd.', 'Valor'];
    $scope.periodo = ['marco', 'abril'];
    $scope.array1 = [0,1];
    $scope.array2 = [0,1];
     /*   [['marco'][0] = [0, "audio", 5, "58.9"]],
        [['marco'][1] = [1,"informatica", 5, "13.2"]]
        [['abril'][0] = [0, "audio", 5, "58.9"]],
        [['abril'][1] = [1,"informatica", 5, "13.2"]]
    ]; */  
    
  /*  $scope.objeto.cd = "dois";
    $scope.objeto.categoria = "audio";
    $scope.objeto.qt = 5;
    $scope.objeto.valor = "58,9";
    $scope.objetos['dois'] = $scope.objeto
    $scope.array.marco = $scope.objetos;

    $scope.objeto.cd = "dezenove";
    $scope.objeto.categoria = "informatica";
    $scope.objeto.qt = 5;
    $scope.objeto.valor = "13,2";
    $scope.objetos['dezenove'] = $scope.objeto
    $scope.array.marco.dezenove = $scope.objetos;

    $scope.objeto.cd = "dois";
    $scope.objeto.categoria = "audio";
    $scope.objeto.qt = 5;
    $scope.objeto.valor = "58,9";
    $scope.objetos['dois']  = $scope.objeto;
    $scope.array.abril = $scope.objetos;

    $scope.objeto.cd = "dezenove";
    $scope.objeto.categoria = "informatica";
    $scope.objeto.qt = 5;
    $scope.objeto.valor = "13,2";
    $scope.objetos['dezenove'] = $scope.objeto
    $scope.array.abril = $scope.objetos;*/

  
       
};

    myController.$inject = ['$scope'];
    angular.module( 'moldes' ).controller( 'myController', myController );