
    var app = angular.module('moldes', []);
    
  

  /*   app.directive("primeira", function() {
      return {
        restrict: 'E',
        templateUrl: "menu.php",
        controller: function(){
          this.tab = 1;

              this.isSelected = function(checkTab) {
                  return this.tab === checkTab;
              };  

              this.selected = function(activeTab) {
                  this.tab = activeTab;
              };
        }
      };
    });*/
    
    


