var app = angular.module('apps', ['720kb.datepicker']);


app.controller('1', function(){
    secondDate="10/02/2017";

    var tokens = secondDate.split("/"); 
    var dt = tokens[1] + "/" + tokens[0] + "/" + tokens[2];
    console.log(dt);
})

app.controller('2', function($scope){
   $scope.dataValida = false;
    function isDateValid(date) {
        console.log("primeiro");
        date=$scope.dataMarota;
        var parts = date.split('/');
        
        var day = parts[0];    
        var month = parts[1]-1;
        var year = parts[2];
        
        var composedDate = new Date(year, month, day);
        if (composedDate === null) return false;    
        
        return (
          composedDate.getDate() == day &&
          composedDate.getMonth() == month &&
          composedDate.getFullYear() == year
        );
      };
      $scope.validarData = function(){
          console.log("Validando data");
          $scope.dataValida = isDateValid();
      }
})






   




