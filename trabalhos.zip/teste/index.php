<?php include('cabecalho.php') ?>
<script src="myController.js"></script>
<!--<script src="diretiva.js"></script> 


<form >
    <primeira></primeira>
    <segunda></segunda>
</form> -->
<!--<div ng-controller="myController">
<table  style="border: 1px solid black">

        <thead >
            <tr> 
                <th rowspan="2"  style="border: 1px solid black"> COD </th>
                <th rowspan="2"  style="border: 1px solid black"> Categoria</th>
                <th rowspan="1" colspan="2"  ng-repeat="p in periodo"  style="border: 1px solid black"> {{p}} </th>
            </tr>
           
        </thead>
        <tbody>
            <td></td>
        <tbody>
    </table>    
    <table>
        <thead>
        
        </thead>
    </table>
</div> -->
<div class="col-xs-6 col-xs-offset-3">
                    <div class="well">
                        <form action="" class="dropzone" dropzone="" id="dropzone">
                            <div class="dz-default dz-message">
                            </div>
                        <form>
                    </div>
                </div>
                <div class="pull-right">
                    <button class="btn btn-success" ng-click="uploadFile()">Upload File</button>
                    <button class="btn btn-danger" ng-click="reset()">Reset Dropzone</button>
                </div>
                <div>
                    <form>
                        <label>File to download</label>
                        <input ng-model="filename" type="text" placeholder="Filename" />
                        <a class="btn btn-primary" href="" ng-href="{{ partialDownloadLink + filename }}">Download File</a>
                    </form>
                </div>

                <div style="width: 100%">
   <div style="width: 50%; float:left">
<img src="" alt="" title="">
<p>Olá</p>
  </div> 
  <div style="width:50%; float:left">
<h1>aqui</h1>
  </div>
</div>


</body>
<html>