/*(function () {


    primeira = function () {
        return {

            templateUrl: "menu.php",
            controller: function () {
                this.tab = 0;

                this.isSelected = function (checkTab) {
                    return this.tab === checkTab;
                };

                this.selected = function (activeTab) {
                    this.tab = activeTab;
                };
            },
            controllerAs: "tab"
        }
    };

    segunda = function () {
        return {
            template: "aqui"
        }
    };

    terceira = function () {
        return {
            templateUrl: "form.php"
        }
    };

    angular.module('moldes').directive('primeira', primeira);
    angular.module('moldes').directive('segunda', segunda);
    angular.module('moldes').directive('terceira', terceira);

}());*/


/*dropzone = function() {
                return {
                    restrict: 'C',
                    link: function(scope, element, attrs) {

                        var config = {
                            url: 'http://localhost:8080/upload',
                            maxFilesize: 100,
                            paramName: "uploadfile",
                            maxThumbnailFilesize: 10,
                            parallelUploads: 1,
                            autoProcessQueue: false
                        };

                        var eventHandlers = {
                            'addedfile': function(file) {
                                scope.file = file;
                                if (this.files[1]!=null) {
                                    this.removeFile(this.files[0]);
                                }
                                scope.$apply(function() {
                                    scope.fileAdded = true;
                                });
                            },

                            'success': function (file, response) {
                            }

                        };

                        dropzoneId = new Dropzone(element[0], config);

                        angular.forEach(eventHandlers, function(handler, event) {
                            dropzone.on(event, handler);
                        });

                        scope.processDropzone = function() {
                            dropzone.processQueue();
                        };

                        scope.resetDropzone = function() {
                            dropzone.removeAllFiles();
                        }
                    }
                }
            };*/

function dropzone(){
                return {
                    retrict: 'C',
                    link: function(scope, element, attrs){
                        var config = {
                            url: 'http://localhost:8080/upload',
                            uploadMultiple: true,
                            paramName: "file",
                            clickable: true,
                            acceptedFiles: 'application/pdf',
                            autoProcessQueue: true
                        };
             
                        var eventHandlers = {
                         'addedfile': function(file) {
                             scope.file = file;
                             if (this.files[1]!=null) {
                                 this.removeFile(this.files[0]);
                             }
                             scope.$apply(function() {
                                 scope.fileAdded = true;
                             });
                         },
             
                         'success': function (file, response) {
                         }
             
                     };
             
                     dropzone = new Dropzone(element[0], config);
             
                     angular.forEach(eventHandlers, function(handler, event) {
                         dropzone.on(event, handler);
                     });
             
                     scope.processDropzone = function() {
                         dropzone.processQueue();
                     };
             
                     scope.resetDropzone = function() {
                         dropzone.removeAllFiles();
                     }
                     
                    }
                } 
            }
            angular.module('moldes').directive('dropzone', dropzone);