<html>
    <head>
     <title>Meu teste </title>   
     <link rel="stylesheet" href="dropzone/dropzone.css">
     <link rel="stylesheet" href="dropzone/basic.css">
    </head>
    <body ng-app="moldes"> 