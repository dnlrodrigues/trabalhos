throw new Error('foo')
